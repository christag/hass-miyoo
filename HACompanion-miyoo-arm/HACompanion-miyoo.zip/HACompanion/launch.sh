#!/bin/sh
cd /mnt/SDCARD/App/HACompanion
HOME=/mnt/SDCARD/App/HACompanion ./hacompanion 2>&1 | tee debug.log
