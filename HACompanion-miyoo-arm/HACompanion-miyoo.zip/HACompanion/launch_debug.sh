#!/bin/sh
cd /mnt/SDCARD/App/HACompanion
echo "=== HACompanion Debug Launch ===" | tee debug.log
echo "Date: $(date)" | tee -a debug.log
echo "Checking dependencies..." | tee -a debug.log
ldd ./hacompanion 2>&1 | tee -a debug.log
echo "Starting app..." | tee -a debug.log
HOME=/mnt/SDCARD/App/HACompanion ./hacompanion 2>&1 | tee -a debug.log
echo "Exit code: $?" | tee -a debug.log
